﻿using Connect_Manager.Common_Layer;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Connnect_Manager.Data_Layer
{
    public  class ManagerDbContext:DbContext
    {
        public ManagerDbContext():base("defaultConnection")
        {
            
        }
        public DbSet<Contact> Contacts { get; set; }
    }
}
