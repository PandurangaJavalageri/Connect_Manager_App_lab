﻿
using Connect_Manager.Common_Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Connnect_Manager.Data_Layer
{
    public class Repos : Irepository
    {
        ManagerDbContext db=new ManagerDbContext();
        public void DeleteContactById(int id)
        {
            var con = db.Contacts.Find(id);
            if(con != null)
            {
                db.Contacts.Remove(con);
            }
            db.SaveChanges();
        }

        public List<Contact> GetAllContact()
        {
            var con =(from c in db.Contacts select c).ToList();
            return con;
        }

        public Contact GetContactById(int id)
        {
            var con = db.Contacts.Find(id);
            return con;
        }

        public void Save(Contact contact)
        {
            db.Contacts.Add(contact);
            db.SaveChanges();
        }

        public void UpdateContactById(Contact contact, int id)
        {
           
            var con=db.Contacts.Find(id);
            if(con != null)
            {
                con.Address = contact.Address;
                con.Email = contact.Email;
                con.Mobile = contact.Mobile;
                con.ContactId = contact.ContactId;
                con.Location  = contact.Location;
                con.Name = contact.Name;
            }
            db.SaveChanges();
        }
    }
}
